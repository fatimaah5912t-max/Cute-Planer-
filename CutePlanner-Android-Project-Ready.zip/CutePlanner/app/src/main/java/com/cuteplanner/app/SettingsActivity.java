package com.cuteplanner.app;
import android.app.*;import android.os.*;import android.content.*;import android.view.*;import android.widget.*;
public class SettingsActivity extends Activity{
 LinearLayout ar,en; boolean english; 
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings); ar=findViewById(R.id.arabicOption);en=findViewById(R.id.englishOption);english=getSharedPreferences("planner",0).getString("lang","ar").equals("en");applyTexts();findViewById(R.id.back).setOnClickListener(v->finish());ar.setOnClickListener(v->setLang("ar"));en.setOnClickListener(v->setLang("en"));}
 void setLang(String s){getSharedPreferences("planner",0).edit().putString("lang",s).apply();english=s.equals("en");applyTexts();}
 void applyTexts(){TextView title=findViewById(R.id.title),sub=findViewById(R.id.subtitle),lab=findViewById(R.id.languageLabel),saved=findViewById(R.id.saved);title.setText(english?"⚙️  Settings":"⚙️  الإعدادات");sub.setText(english?"Customize your planner your way ♡":"خصصي مخططك بالطريقة التي تحبينها ♡");lab.setText(english?"🌐  Language":"🌐  اللغة");saved.setText(english?"✓  Your choice is saved automatically":"✓  يتم حفظ اختيارك تلقائيًا");ar.setBackgroundResource(english?R.drawable.bg_card:R.drawable.bg_language_selected);en.setBackgroundResource(english?R.drawable.bg_language_selected:R.drawable.bg_card);getWindow().getDecorView().setLayoutDirection(english?View.LAYOUT_DIRECTION_LTR:View.LAYOUT_DIRECTION_RTL);}
}
