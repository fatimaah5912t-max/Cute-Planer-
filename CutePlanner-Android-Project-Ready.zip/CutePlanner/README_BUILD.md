# CutePlanner Android Project

This project has been prepared for Android Studio / Gradle builds.

## Build APK
1. Open the `CutePlanner` folder in Android Studio.
2. Allow Gradle to sync and download the required Gradle/Android components.
3. Use **Build > Build APK(s)**.
4. The debug APK will normally be generated under `app/build/outputs/apk/debug/`.

## Project requirements
- Android Gradle Plugin: 8.6.1
- Gradle: 8.10.2
- compileSdk: 35
- minSdk: 23
- Java: 17+

## Fixes in this prepared version
- Fixed the Settings navigation crash caused by a mismatched view ID.
- Added Java 17 compile options.
- Added Gradle wrapper configuration.
- Kept the Arabic/English language selection and existing CutePlanner UI.

Note: the Gradle wrapper JAR is intentionally not embedded in this archive, so Android Studio can use/download the configured Gradle distribution.
